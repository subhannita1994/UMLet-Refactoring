This directory contains the UML metamodel definitions.

UML 1.3
 - 01-12-02.xml - <deleted> base UML definition - available at 
       http://www.omg.org/cgi-bin/doc?ad/01-12-02
 - 01-12-02_Diff.xml - Java diffs from 
       http://mdr.netbeans.org/source/browse/mdr/xmidiffs/01-12-02_Diff.xml?rev=1.5
 - 99-10-15.dtd - UML 1.3 DTD <deleted>
                    available from  http://www.omg.org/docs/ad/99-10-15.dtd 
                                or  ftp://ftp.omg.org/pub/docs/ad/99-10-15.dtd

UML 1.4
 - 01-02-15.xml - base UML definition from OMG site at 
       http://www.omg.org/cgi-bin/doc?ad/01-02-15
 - 01-02-15_Diff.xml - Java binding changes from openmodel project 
                       (probably from NetBeans MDR originally)

UML 1.4 + UML 2.0 Diagram Interchange
 - M2_DiagramInterchangeModel.xml - <deleted> - reportedly from Poseidon via AndroMDA
 
UML 1.5 
 - ActionUML_Interchange_MetaModel_FTF.xml - base UML definintion - <deleted>
        available from OMG http://www.omg.org/cgi-bin/doc?formal/2004-04-04
 - ActionUML_Interchange_MetaModel_FTF_omg_Diff.xml - Java binding diffs - from ???
